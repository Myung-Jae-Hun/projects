package com.example.template;

public enum DeliveryStatus {
    DeliveryStarted, DeliveryCancelled, DeliveryCompleted
}
