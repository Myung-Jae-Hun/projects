package com.example.template.delivery;

public enum  DeliveryStatus {
    DeliveryStarted, DeliveryCancelled, DeliveryCompleted
}
